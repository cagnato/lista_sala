# Crie um algoritmo que peça ao usuário para informar 5 valores inteiros
# positivos e armazene-os em uma lista com nome qualquer. Em seguida,
# crie uma nova lista ordenada dos valores e uma nova lista com os valores
# ordenados em ordem inversa. Imprima na tela:
# a. As três listas
# b. O tamanho da lista
# c. O menor valor informado
# d. O maior valor informado
# e. A soma de todos os valores da lista
# Exercício

lista = []

for i in range(5):
    
    num = int(input(f"Digite o {1+i}º número positivo: "))

    if num >= 0:
        lista.append(num)
    else:
        print("Digite um número válido")
        break
    listaOrd = sorted(lista)
    listaInvers = list(reversed(lista))
    listaTamanho = len(lista)
    listaMenor = min(lista)
    listaMaior = max(lista)
    listaSoma = sum(lista)

print(lista)
print(listaOrd)
print(listaInvers)
print(listaTamanho)
print(listaMenor)
print(listaMaior)
print(listaSoma)