import random

numerosJogador1 = []
numerosJogador2 = []

for i in range(3):
    numerosJogador1.append(random.randint(1, 6))
    numerosJogador2.append(random.randint(1, 6))

print(f"O resultado dos dados do jogador 1 é {numerosJogador1}")
print(f"O resultado dos dados do jogador 2 é {numerosJogador2}")

soma1 = sum(numerosJogador1)
soma2 = sum(numerosJogador2)

print(f"A soma dos dados do jogador 1 é {soma1}")
print(f"A soma dos dados do jogador 2 é {soma2}")

if soma1 > soma2:
    print(f"O jogador 1 é o vencedor!")
elif soma1 == soma2:
    print(f"Deu empate!")
else:
    print(f"O jogador 2 é o vencedor!")
